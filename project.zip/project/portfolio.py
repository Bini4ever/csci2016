import sqlite3

def main():
    fileName = ''
    disc = {}
    choise = input('(A)dd/(D)elete stocks, (L)oad file, (U)pdate prices, (R)eport, or (Q)uit? ')

    while (choise.upper() != 'Q'):
        if (choise.upper() == 'L'):
            fileName = input('Load file: ')
            print()
            portfolioList = sqlite3.connect(fileName)
            cursor = portfolioList.execute('select * from portfolioList order by t1')
            disc = creatDisc(cursor)
            portfolioList.commit()

        elif (choise.upper() == 'R'):
            sortby = input('Sort output on (N)ame, or (V)alue? ')
            if (sortby.upper() == 'N'):
                sortByName(fileName)
            elif (sortby.upper() == 'V'):
                sortByValue(fileName)

        elif (choise.upper() == 'A'):
            addTicker(fileName)

        elif (choise.upper() == 'd'):
            removeTicker(fileName)

        elif (choise.upper() == 'u'):
            updatePrices(fileName)

        choise = input('(A)dd/(D)elete stocks, (L)oad file, (U)pdate prices, (R)eport, or (Q)uit? ')



    

def creatDisc(cursor):
    d = {}
    for row in cursor:
        gl = ((row[4] - row[3]) * 100)/row[3]
        d[row[1]] = [row[0], row[1], row[2], row[3], row[4], row[2] * row[4], gl]
    return d



def addTicker(fileName):

    print('Add a stock to your portfolio...')
    print()

    ticker = input('Ticker: ')
    name = input('Company Name: ')
    number = int(input('Number of shares: '))
    price = float(input('Purchase price per share: $'))

    portfolioList = sqlite3.connect(fileName)
    portfolioList.execute('insert into portfolioList (t1, t2, i1, i2, i3, i4) values (?, ?, ?, ?, ?, ?)', (ticker, name, number, price, price, number*price))
    portfolioList.commit()




def removeTiker(fileName):

    symbol = input("Enter the ticker symbol of the stock to remove: ")

    portfolioList = sqlite3.connect(fileName)
    portfolioList.execute('delete from studentList where t1 = ?', (symbol,))
    portfolioList.commit()





def updateTicker(fileName):
    print('Update stock prices (<Return> to keep current value)...')
    print()
    portfolioList = sqlite3.connect(fileName)
    cursor = portfolioList.execute('select * from portfolioList order by t2')

    for row in cursor:
        value = float(input(row[0], ' : '))
        portfolioList.execute('update stock price i3 = ?', (value,))
        portfolioList.execute('update value i4 = ?', ((row[2] * value),)) 

    portfolioList.commit()       



def sortByName(fileName):
 
    portfolioList = sqlite3.connect(fileName)
    cursor = portfolioList.execute('select * from portfolioList order by t2')
    disc = creatDisc(cursor)

    displayList(disc)
    portfolioList.commit()



def sortByValue(fileName):

    portfolioList = sqlite3.connect(fileName)
    cursor = portfolioList.execute('select * from portfolioList order by i4')
    disc = creatDisc(cursor)

    displayList(disc)
    portfolioList.commit()



    

def displayList(d):
    total = 0.0
    totalgl = 0.0

    for key in d.keys():
        total += d[key][5]
        totalgl += d[key][6]

    tab1 = "\t"
    tab2 = "\t\t"
    tab3 = "\t\t\t"
    tab4 = "\t\t\t\t"

    print('Company\t\t\t\t\tShares\tPur.\tLatest\tValue\tG/L')
    print('=================================================================')
    for key in d.keys():
        if (len(key + d[key][0]) > 20):
            print(key, '(', d[key][0], ')', tab1 , d[key][2], '\t', d[key][3], '\t', d[key][4], '\t',d[key][5], '\t', "{:.2f}".format(d[key][6]), '%')
        elif (len(key + d[key][0]) > 15):
            print(key, '(', d[key][0], ')', tab2 , d[key][2], '\t', d[key][3], '\t', d[key][4], '\t',d[key][5], '\t\t', "{:.2f}".format(d[key][6]), '%')
        elif (len(key + d[key][0]) > 9):
            print(key, '(', d[key][0], ')', tab3 , d[key][2], '\t', d[key][3], '\t', d[key][4], '\t',d[key][5], '\t\t', "{:.2f}".format(d[key][6]), '%')
        elif (len(key + d[key][0]) > 5):
            print(key, '(', d[key][0], ')', tab4 , d[key][2], '\t', d[key][3], '\t', d[key][4], '\t',d[key][5], '\t\t', "{:.2f}".format(d[key][6]), '%')
    print('\t\t\t\t\t\t\t---------------')
    print('\t\t\t\t\t\t\t', "{:.2f}".format(total), '\t', "{:.2f}".format(totalgl))
    print('\t\t\t\t\t\t\t===============')

    

if __name__ == "__main__":
    main()
